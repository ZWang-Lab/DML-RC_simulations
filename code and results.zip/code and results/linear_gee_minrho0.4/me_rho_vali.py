import sys
sys.path.insert(0,'/gpfs/gibbs/project/xiting_yan/gx28/python_lib')
import numpy as np
import pandas as pd
from math import sqrt
import pickle
import time
import math
from math import sin
from math import cos
from math import pi
from minimax_tilting_sampler import TruncatedMVN # for truncated MVNs
import generate_data
import reg_dml
import statsmodels.api as sm
from doubleml import DoubleMLData
from doubleml import DoubleMLPLR
from sklearn.linear_model import LinearRegression
from sklearn import linear_model
from sklearn.ensemble import RandomForestRegressor
from sklearn.base import clone
from scipy import stats
from doubleml.datasets import make_plr_CCDDHNR2018
from sklearn.ensemble import RandomForestRegressor
from sklearn.neural_network import MLPRegressor
import multiprocessing as mp


n1=350
n2=1000



####################fitted means for generating personal measures

mean_cu=0.00968
mean_s=0.737
mean_zn=0.019
mean_ni=0.00145
mean_al=0.011
mean_ca=0.128

mean_v=0.00130
mean_mg=-0.00129
mean_k=0.0922
mean_cl=0.0656
mean_na=0.00118
mean_si=0.14

mean_br=0.00259
mean_pb=0.00186
mean_se=0.00021
mean_mn=0.0025
mean_ti=0.00638




age_min=18
age_max=91

#####################adjustment#############
b_cu=0
b_zn=0
b_ni=0
b_al=0
b_ca=5
b_v=0
b_mg=0
b_k=0
b_cl=0
b_na=0
b_si=0
b_br=0
b_pb=0
b_se=0
b_mn=0
b_ti=0
b_age=0
b_race=0

######

b_0=1
b_x=8 # beta for X (S_per)
sd_xi=3 # sd for the error in main model

st=time.time()



np.random.seed(1234)
v=generate_data.ge_right2(n1,age_min,age_max,mean_cu,mean_s,mean_zn,mean_ni,mean_al,mean_ca,mean_v,mean_mg,mean_k,mean_cl,mean_na,mean_si,
             mean_br,mean_pb,mean_se,mean_mn,mean_ti)

x_per_v=v[0]["S_per"]
x_nm_v=v[0]["S_nm"]
w1_per_v=v[0][['Cu_per','Zn_per','Ni_per','Al_per','Ca_per','V_per','Mg_per','K_per','Cl_per','Na_per','Si_per','Br_per','Pb_per','Se_per','Mn_per','Ti_per']]
w1_nm_v=v[0][['Cu_nm','Zn_nm','Ni_nm','Al_nm','Ca_nm','V_nm','Mg_nm','K_nm','Cl_nm','Na_nm','Si_nm','Br_nm','Pb_nm','Se_nm','Mn_nm','Ti_nm']]
w2_v=v[0][["age","race"]]

nm_column=['Cu_nm','S_nm','Zn_nm','Ni_nm','Al_nm','Ca_nm','V_nm','Mg_nm','K_nm','Cl_nm','Na_nm',
    'Si_nm','Br_nm','Pb_nm','Se_nm','Mn_nm','Ti_nm']

per_column=['Cu_per','S_per','Zn_per','Ni_per','Al_per','Ca_per','V_per','Mg_per','K_per','Cl_per',
    'Na_per','Si_per','Br_per','Pb_per','Se_per','Mn_per','Ti_per']

nm=v[0][nm_column]
per=v[0][per_column]
nm_per_corr=np.zeros((len(nm_column)))
for i in range(len(nm_column)):
    nm_per_corr[i]=np.corrcoef(nm[nm_column[i]],per[per_column[i]])[0,1]

et=time.time()

# Creating dataset
print("Execution time:",et-st, "seconds")
print("Correlations:",nm_per_corr,"Min is:",np.amin(nm_per_corr))
