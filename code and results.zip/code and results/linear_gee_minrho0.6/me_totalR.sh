#!/bin/bash
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=5
#SBATCH --mem-per-cpu=10G
#SBATCH --time=24:00:00
#SBATCH --job-name=dml_test2

module load Python
python me_totalR.py > me_totalR.txt