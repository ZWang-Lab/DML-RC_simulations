import sys
sys.path.insert(0,'/gpfs/gibbs/project/xiting_yan/gx28/python_lib')
import numpy as np
import pandas as pd
from math import sqrt
import pickle
import time
import math
from math import sin
from math import cos
from math import pi
from minimax_tilting_sampler import TruncatedMVN # for truncated MVNs
import generate_data
import reg_dml
import statsmodels.api as sm
from doubleml import DoubleMLData
from doubleml import DoubleMLPLR
from sklearn.linear_model import LinearRegression
from sklearn import linear_model
from sklearn.ensemble import RandomForestRegressor
from sklearn.base import clone
from scipy import stats
from doubleml.datasets import make_plr_CCDDHNR2018
from sklearn.ensemble import RandomForestRegressor
from sklearn.neural_network import MLPRegressor
import multiprocessing as mp
import warnings
warnings.filterwarnings("ignore")

####################fitted means for generating personal measure
mean_x=np.array([0.00968,0.737,0.019,0.00145,0.011,0.128,0.00130,-0.00129,0.0922,0.0656,0.00118,0.14])
b_x=8
b_w=np.array([0,0,0,0,16,0,0,0,0,0,0,0,0])
sigma_x=np.loadtxt("per_sigma.txt")
sigma_ep=np.loadtxt("error_sigma_rho0.4.txt")
age_min=18
age_max=91

n1=350
n2=1000

b_0=1
sd_xi=10 # sd for the error in main model


lm_lasso=[]
st=time.time()

np.random.seed(12345)
v=generate_data.ge_right(n1,age_min,age_max,mean_x,sigma_x,sigma_ep)

random_seeds=range(1234,3234,1)

def wrapped(i,rand_seed):
    np.random.seed(rand_seed)
    m=generate_data.ge_main(n2,age_min,age_max,mean_x,b_0,b_x,b_w,sd_xi,sigma_x,sigma_ep,False)
    results=np.concatenate((m[3],m[2],m[4]),axis=None)    
    return results
pool = mp.Pool(5)
results = pool.starmap(wrapped, [(i,random_seeds[i]) for i in range(2000)])
pool.close()
results=np.array(results)
print("1-Total R square is",np.mean(results[:,0]),"\t","R square for X is",np.mean(results[:,1]),"\t","R square for g is",np.mean(results[:,2]))



###Case 2
b_w=np.array([0,0,0,0,16,0,0,0,0,0,0,0,0])
sd_xi=7 # sd for the error in main model
np.random.seed(12345)
v=generate_data.ge_right(n1,age_min,age_max,mean_x,sigma_x,sigma_ep)

random_seeds=range(1234,3234,1)

def wrapped(i,rand_seed):
    np.random.seed(rand_seed)
    m=generate_data.ge_main(n2,age_min,age_max,mean_x,b_0,b_x,b_w,sd_xi,sigma_x,sigma_ep,False)
    results=np.concatenate((m[3],m[2],m[4]),axis=None)    
    return results
pool = mp.Pool(5)
results = pool.starmap(wrapped, [(i,random_seeds[i]) for i in range(2000)])
pool.close()
results=np.array(results)
print("1-Total R square is",np.mean(results[:,0]),"\t","R square for X is",np.mean(results[:,1]),"\t","R square for g is",np.mean(results[:,2]))

##Case 3
b_w=np.array([8,0,0,0,8,0,0,8,0,0,0,0,8])
sd_xi=10 # sd for the error in main model
np.random.seed(12345)
v=generate_data.ge_right(n1,age_min,age_max,mean_x,sigma_x,sigma_ep)

random_seeds=range(1234,3234,1)

def wrapped(i,rand_seed):
    np.random.seed(rand_seed)
    m=generate_data.ge_main(n2,age_min,age_max,mean_x,b_0,b_x,b_w,sd_xi,sigma_x,sigma_ep,False)
    results=np.concatenate((m[3],m[2],m[4]),axis=None)    
    return results
pool = mp.Pool(5)
results = pool.starmap(wrapped, [(i,random_seeds[i]) for i in range(2000)])
pool.close()
results=np.array(results)
print("1-Total R square is",np.mean(results[:,0]),"\t","R square for X is",np.mean(results[:,1]),"\t","R square for g is",np.mean(results[:,2]))


##Case 4
b_w=np.array([8,0,0,0,8,0,0,8,0,0,0,0,8])
sd_xi=7 # sd for the error in main model

np.random.seed(12345)
v=generate_data.ge_right(n1,age_min,age_max,mean_x,sigma_x,sigma_ep)

random_seeds=range(1234,3234,1)

def wrapped(i,rand_seed):
    np.random.seed(rand_seed)
    m=generate_data.ge_main(n2,age_min,age_max,mean_x,b_0,b_x,b_w,sd_xi,sigma_x,sigma_ep,False)
    results=np.concatenate((m[3],m[2],m[4]),axis=None)    
    return results
pool = mp.Pool(5)
results = pool.starmap(wrapped, [(i,random_seeds[i]) for i in range(2000)])
pool.close()
results=np.array(results)
print("1-Total R square is",np.mean(results[:,0]),"\t","R square for X is",np.mean(results[:,1]),"\t","R square for g is",np.mean(results[:,2]))



et=time.time()
print("Execution time:",et-st, "seconds")
